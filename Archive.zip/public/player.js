var Player = function(name, gamesPlayed){                                       // unused constructor, for use with future features
  this.name = name;
  this.gamesPlayed = gamesPlayed;
};

Player.prototype = {
  input: function(str){


  }
};
